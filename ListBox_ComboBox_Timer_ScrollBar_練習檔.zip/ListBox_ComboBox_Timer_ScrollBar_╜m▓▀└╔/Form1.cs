﻿using System;
using System.Windows.Forms;
using System.Resources;
using System.Drawing;

namespace ListBox_ComboBox_Timer_ScrollBar
{
    public partial class Form1 : Form
    {
        //Step 1
        //宣告全域變數：
        //pic作為三張圖片的PictureBox陣列，未指定內容；
        //picFruit為水果圖片名稱的string陣列；
        //picHalloween為萬聖節圖片名稱的string陣列；
        PictureBox[] pic;
        string[] picFruit = { "水梨", "西瓜", "奇異果", "草莓", "蘋果", "櫻桃" };
        string[] picHalloween = { "南瓜", "巫婆", "幽靈", "滿月", "蜘蛛", "蝙蝠", "蘑菇" };
        public Form1()
        {
            InitializeComponent();
            //Step 2
            //初始化設定
            //comboBox1項目增加：水果、萬聖節選單
            listBox1.MultiColumn = true;
            listBox1.SelectionMode = SelectionMode.MultiSimple;
            comboBox1________________________;
            comboBox1________________________;
            //pic取得現有物件pictureBox1、pictureBox2、pictureBox3
            pic = new PictureBox[] { _____________________, _____________________, _____________________ };
            //先關閉listBox1、btnRotate、btnStop的功能
            listBox1________________________;
            btnRotate________________________;
            btnStop________________________;
        }
        //Step 3 
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //選項有變更時，先清除listBox1
            listBox1________________________;
            //致能listBox1
            listBox1________________________;
            //根據comboBox1的選擇，顯示listBox1內容
            switch (________________________)
            {
                case "水果":
                    foreach (string i in ________________________)
                    {
                        listBox1________________________;
                    }
                    break;
                case "萬聖節":
                    foreach (string i in ________________________)
                    {
                        listBox1________________________;
                    }
                    break;
            }
        }
        //Step 4
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //判斷listBox1選項是否至少一個被選取，再開啟btnRotate功能
            if (listBox1________________________ != 0) btnRotate.Enabled = true;
            else btnRotate.Enabled = false;
        }
        //Step 5
        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            //水平卷軸移動時，更改timer1.Interval屬性值
            //如果timer1正在啟用，先關閉再設定Interval
            if (timer1.Enabled)
            {
                timer1.Enabled = false;
                timer1.Interval = ________________________;
                timer1.Enabled = true;
            }
            else timer1.Interval = ________________________;
        }
        //Step 6
        private void btnRotate_Click(object sender, EventArgs e)
        {
            //啟用後關閉功能，避免重複啟用；致能btnStop按鈕
            btnRotate ________________________;
            btnStop ________________________;
            //圖片旋轉時，禁用comboBox1、listBox1
            comboBox1 ________________________;
            listBox1 ________________________;
            //label5的文字內容重新設置
            label5.Text = "連線判斷：。。。。";
            //致能timer1，控制圖片變換
            timer1 ________________________;
        }
        //Step 7
        private void timer1_Tick(object sender, EventArgs e)
        {
            //Interval間隔時機一到，就會執行Tick事件：隨機顯示已選取的圖片
            //宣告ResourceManager以便管理資源檔案
            ResourceManager rm = new ResourceManager(typeof(_______________________));
            //宣告Random型別可以取亂數
            Random rd = new Random();
            //設定pic[]陣列的圖片來源
            foreach (PictureBox p in pic)
            {
                //設定圖片的Tag，以便辨識圖片是否相同
                int a = rd.Next(________________________);
                p.Tag = a;
                p.Image = ________________________;
            }
        }
        //Step 8
        private void btnStop_Click(object sender, EventArgs e)
        {
            //各控制項致能相關設定
            btnRotate.Enabled = true;
            btnStop.Enabled = false;
            comboBox1.Enabled = true;
            listBox1.Enabled = true;
            timer1.Enabled = false;
            //判別圖片是否相同
            if (________________________ && ________________________) label5.Text = "兌獎訊息：連線成功～";
            else label5.Text = "兌獎訊息：連線失敗～";
        }
    }
}